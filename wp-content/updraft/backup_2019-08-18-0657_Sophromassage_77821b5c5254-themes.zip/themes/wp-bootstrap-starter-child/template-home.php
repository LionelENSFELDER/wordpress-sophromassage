<?php
/*
Template Name: Template-Home
*/

get_header();
?>

<!-- #full-width section template -->
<!--
<section class="section bg-secondary w-100 p-5">
    <div class="container">
        <div class="row">
            <div class="col-sm bg-info">
                One of three columns
            </div>
            <div class="col-sm">
                One of three columns
            </div>
        </div>
    </div>
</section>
-->

<!-- #full-width section template -->
<section class="section w-100 p-5">
    <div class="container">
        <div class="row card-deck">
            <!-- COL -->
            <div class="col-sm">
                <!-- CARD -->
                <div class="p-4 border-right">
                    <div class="">
                        <div class="mb-3">
                            <i class="fas fa-heart mr-2 ico-m font-pink"></i>
                            <span class="font-weight-bold text-secondary">SOPHROLOGIE</span>
                        </div>
                        <p class="card-text">Comprendre et gérer vos émotions, apprivoiser le stress et l'anxiété.</p>
                        <button type="button" class="btn btn-outline-secondary">Secondary</button>
                    </div>
                </div>
                <!-- CARD END-->
            </div>
            <!-- COL END -->
            <div class="col-sm">
            <!-- CARD -->
            <div class="p-4 border-right">
                    <div class="">
                        <div class="mb-3">
                            <i class="fas fa-spa mr-2 ico-m font-pink"></i>
                            <span class="font-weight-bold text-secondary">MASSAGES BIEN-ETRE</span>
                        </div>
                        <p class="card-text">Découvrez mes méthodes de massage pour vous faire plaisir tout en douceur.</p>
                        <button type="button" class="btn btn-outline-secondary">Secondary</button>
                    </div>
                </div>
                <!-- CARD END-->
            </div>
            <div class="col-sm">
            <!-- CARD -->
            <div class="p-4">
                    <div class="">
                        <div class="mb-3">
                            <i class="fas fa-running mr-2 ico-m font-pink"></i>
                            <span class="font-weight-bold text-secondary">MASSAGES BIEN-ETRE SPORTIFS</span>
                        </div>
                        <p class="card-text">Avant l'effort, après l'effort ou conditionnement physique.</p>
                        <button type="button" class="btn btn-outline-secondary">Secondary</button>
                    </div>
                </div>
                <!-- CARD END-->
            </div>
        </div>
        <!-- END CARD DECK-->
    </div>
</section>


<!-- #full-width section template -->
<section class="section w-100 p-5">
    <div class="container">
        <div class="row">
            <div class="col-6">
                <div class="card border-0">
                    <div class="card-body">
                        <h3 class="card-title">Lorem ipsum dolor sit ame</h3>
                        <p class="card-text">consectetur adipiscing elit. Etiam sit amet ligula scelerisque, 
                            dignissim metus eu, scelerisque ante. Donec quis elit varius, pulvinar erat eu, 
                            rhoncus ligula. Aliquam erat volutpat. Integer eget nisi risus
                        </p>
                        <p>
                            <div class="mb-3">
                                <i class="fas fa-leaf mr-2 ico-s font-light-grey"></i>
                                <span class="text-secondary">Donec nec sapien non ncidunt.</span>
                            </div>
                            <div class="mb-3">
                                <i class="fas fa-heartbeat mr-2 ico-s font-light-grey"></i>
                                <span class="text-secondary">Donec nec saphatincidunt.</span>
                            </div>
                            <div class="mb-3">
                                <i class="fas fa-shoe-prints mr-2 ico-s font-light-grey"></i>
                                <span class="text-secondary">Curabitur quis rerit vel et magna.</span>
                            </div>
                        </p>
                        <button type="button" class="btn btn-link">Tous les tarifs</button>
                    </div>
                </div>
            </div>
            <div class="col-6">
                <!-- pricing card template 1-->
                <div class="row card-deck">
                    <div class="card bg-4 text-white text-center rounded border-0 shadow">
                        <div class="card-header text-white">
                            <h3 class="card-title text-white">Sophrologie</h3>
                            <span class="">A partir de </span>
                            <h1 class="text-white card-title font-weight-bold">12€</h1>
                        </div>
                        <div class="card-body">
                            <p class="card-text my-5">
                                <span class="mb-3 d-block">Séance individuelle</span>
                                <span class="mb-3 d-block">Séance collective</span>
                                <span class="d-block">Professionnel, milieux sportif et associatif</span>
                            </p>
                        </div>
                        <div class="card-footer bg-transparent border-0">
                            <a href="#" class="btn btn-outline-light">Tous les tarifs</a>
                        </div>
                    </div>
        
                    <!-- pricing card template 2-->
                    <div class="card text-center rounded shadow">
                        <div class="card-header bg-transparent">
                            <h3 class="card-title">Massages</h3>
                            <span class="">A partir de </span>
                            <h1 class="card-title font-weight-bold">15€</h1>
                        </div>
                        <div class="card-body">
                            <p class="card-text my-5">
                                <span class="mb-3 d-block">Amma Assis</span>
                                <span class="mb-3 d-block">Relaxation coréenne</span>
                                <span class="mb-3 d-block">Massage californien</span>
                            </p>
                        </div>
                        <div class="card-footer bg-transparent border-0">
                            <a href="#" class="btn btn-dark">Tous les tarifs</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>


<!-- Qui suis-je ? -->
<div class="section w-100 p-5">
    <div class="container">
        <div class="card-deck">
            <div class="card border-0" style="width: 18rem;">
                <div class="card-body">
                    <h5 class="card-title">Qui suis-je ?</h5>
                    <p class="card-text">
                        Après avoir travaillé plusieurs années dans le secteur Médico-technique, j'ai décidé d’accroître
                        mon expérience par des formations complètes et enrichissantes.

                        Je suis aujourd'hui praticienne certifiée en massages bien-être et sportifs de l'Institut Ling
                        Dao, agrée par la FFPMM et Sophrologue formée auprès de l'IFS à Nice.

                        fdghdf g dhgfgdh fgh fjhghj fgjfdh fjdh fhjfh fhf
                        fgh fdhdfhfgh fdgjhfjd ffgjhdfhfgh fdhdfgh dfhf gh

                        Je suis Eléonore, votre thérapeute.
                    </p>
                    <button type="button" class="btn btn-link">Link</button>
                </div>
            </div>

            <div class="card bg-dark text-white shadow-lg">
                <img src="http://localhost:8080/sophromassage/wp-content/uploads/2019/07/eleonor-hottou.jpg"
                    class="card-img" alt="...">
                <div class="card-img-overlay">
                <div>
                <i class="fas fa-heart fa-5x"></i>
                </div>
                </div>
            </div>

            <div class="card border-0" style="width: 18rem;">
                <div class="card-body">
                    <h5 class="card-title">Special title treatment</h5>
                    <p class="card-text">With supporting text below as a natural lead-in to additional content.</p>
                    <a href="#" class="btn btn-primary">Go somewhere</a>
                </div>
            </div>
        </div>
    </div>
</div>



<!-- Qui suis-je ? -->
<div class="section w-100 bg-1">
    <div class="p-5">
        <div class="container">
            <div class="row">
            <div class="col-6">
                    <div class="">
                        <img class="h-100" src="http://localhost:8080/sophromassage/wp-content/uploads/2019/07/generic.jpg" title="" alt="">
                    </div>
                </div>
                <div class="col-6 text-left">
                    <ul class="nav nav-pills mb-3" id="pills-tab" role="tablist">
                        <li class="nav-item">
                            <a class="nav-link active" id="pills-qsj-tab" data-toggle="pill" href="#pills-qsj" role="tab" aria-controls="pills-home" aria-selected="true">Qui suis-je ?</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" id="pills-ma-tab" data-toggle="pill" href="#pills-ma" role="tab" aria-controls="pills-profile" aria-selected="false">Mon approche</a>
                        </li>
                    </ul>
                    <div class="tab-content" id="pills-tabContent">
                        <div class="tab-pane fade show active" id="pills-qsj" role="tabpanel" aria-labelledby="pills-qsj-tab">
                            <p>
                                Après avoir travaillé plusieurs années dans le secteur Médico-technique, 
                                j'ai décidé d’accroître mon expérience par des formations complètes et enrichissantes.
                            </p>
                            <p>
                                Je suis aujourd'hui praticienne certifiée en massages bien-être et sportifs 
                                de l'Institut Ling Dao, agrée par la FFPMM et Sophrologue formée auprès de l'IFS à Nice.
                                <ul>
                                    <li>fdghdf g dhgfgdh fgh fjhghj fgjfdh fjdh fhjfh fhf</li>
                                    <li>fgh fdhdfhfgh fdgjhfjd ffgjhdfhfgh fdhdfgh dfhf gh </li>
                                </ul>
                            </p>
                            <span class="font-weight-bold">Je suis Eléonore, votre thérapeute.</span>
                        </div>
                        <div class="tab-pane fade" id="pills-ma" role="tabpanel" aria-labelledby="pills-ma-tab">
                            <p>
                                Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla ac metus lectus. 
                                Nullam sit amet rhoncus massa. Nunc id nisl eros. Fusce fringilla mi quis placerat 
                                elementum. Cras ut magna id odio tincidunt vulputate. Interdum et malesuada fames 
                                ac ante ipsum primis in faucibus. Nullam congue sapien augue, vestibulum aliquam eros iaculis non. 
                                Phasellus vitae dui id quam volutpat fermentum. Vivamus non metus euismod, iaculis est ut, 
                                tempus justo. Mauris urna orci, facilisis placerat neque vel, placerat venenatis metus. Vivamus 
                                vitae diam pellentesque ipsum tristique molestie. Lorem ipsum dolor sit amet, consectetur 
                                adipiscing elit. In lorem elit, eleifend placerat libero a, consectetur blandit magna.
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!--  -->
<section class="section w-100 p-5">
    <div class="container">
        <div class="row">
            <!-- COL -->
            <div class="col-sm">
                <!-- CARD -->
                <div class="card">
                    <img src="http://localhost:8080/sophromassage/wp-content/uploads/2019/07/generic.jpg" class="card-img-top" alt="...">
                    <div class="card-body">
                        <h5 class="card-title">Sophrologie</h5>
                        <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                        <a href="#" class="btn btn-link">Go somewhere</a>
                    </div>
                </div>
                <!-- CARD END-->
            </div>
            <!-- COL -->
            <div class="col-sm">
            <!-- CARD -->
            <div class="card">
                    <img src="http://localhost:8080/sophromassage/wp-content/uploads/2019/07/generic.jpg" class="card-img-top" alt="...">
                    <div class="card-body">
                        <h5 class="card-title">Massages bien-être</h5>
                        <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                        <a href="#" class="btn btn-link">Go somewhere</a>
                    </div>
                </div>
            </div>
            <!-- COL -->
            <div class="col-sm">
            <!-- CARD -->
            <div class="card">
                    <img src="http://localhost:8080/sophromassage/wp-content/uploads/2019/07/generic.jpg" class="card-img-top" alt="...">
                    <div class="card-body">
                        <h5 class="card-title">Massages bien-être sportifs</h5>
                        <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                        <a href="#" class="btn btn-link">Go somewhere</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- #full-width section template -->
<section class="section w-100 p-5 bg-2">
    <div class="container">
        <div class="row row-eq-height"><!-- !!! row-eq-height !!! -->
            <div class="col-6">
                <div class="h-100">
                    <img src="http://localhost:8080/sophromassage/wp-content/uploads/2019/07/generic2.jpg" class="img-fluid" alt="Responsive image">
                </div>
            </div>
            <!-- COL -->
            <div class="col-6">
                <!-- CARD -->
                <div class="mb-5 p-4 shadow rounded-lg">
                    <div class="">
                        <div class="mb-3">
                            <i class="fas fa-star mr-2 ico-m font-light-grey"></i>
                            <span class="">Special title treatment</span>
                        </div>
                        <p class="card-text">With supporting text below as a natural lead-in to additional content.</p>
                    </div>
                </div>
                <!-- CARD END-->

                <!-- CARD -->
                <div class="mb-5 p-4 shadow rounded-lg">
                    <div class="">
                        <div class="mb-3">
                            <i class="fas fa-star mr-2 ico-m font-light-grey"></i>
                            <span class="">Special title treatment</span>
                        </div>
                        <p class="card-text">With supporting text below as a natural lead-in to additional content.</p>
                    </div>
                </div>
                <!-- CARD END-->

                <!-- CARD -->
                <div class="p-4 shadow rounded-lg">
                    <div class="">
                        <div class="mb-3">
                            <i class="fas fa-star mr-2 ico-m font-light-grey"></i>
                            <span class="">Special title treatment</span>
                        </div>
                        <p class="card-text">With supporting text below as a natural lead-in to additional content.</p>
                    </div>
                </div>
                <!-- CARD END-->

                <!-- CARD -->
                <div class="p-4 shadow rounded-lg">
                    <div class="">
                        <div class="mb-3">
                            <i class="fas fa-star mr-2 ico-m font-light-grey"></i>
                            <span class="">Special title treatment</span>
                        </div>
                        <p class="card-text">With supporting text below as a natural lead-in to additional content.</p>
                    </div>
                </div>
                <!-- CARD END-->
            </div>
            <!-- COL END -->
        </div>
    </div>
</section>
<!-- END full-width section template -->

<!-- #full-width section template -->
<section class="section w-100 p-5 bg-4">
    <div class="container">
        <div class="my-5 text-white">
            <div class="row card-group">
                <!-- COL -->
                <div class="col-sm">
                    <!-- CARD -->
                    <div class="text-center">
                        <div class="mx-auto">
                            <div class="mb-3">
                            <i class="fas fa-bolt fa-3x"></i>
                            </div>
                            <span class="card-text">With supporting text below as a natural lead-in to additional content.</span>
                        </div>
                    </div>
                    <!-- CARD END-->
                </div>
                <!-- COL END -->
                <!-- COL -->
                <div class="col-sm">
                    <!-- CARD -->
                    <div class="text-center">
                        <div class="mx-auto">
                            <div class="mb-3">
                            <i class="fas fa-hand-holding-heart fa-3x"></i>
                            </div>
                            <span class="card-text">With supporting text below as a natural lead-in to additional content.</span>
                        </div>
                    </div>
                    <!-- CARD END-->
                </div>
                <!-- COL END -->
                <!-- COL -->
                <div class="col-sm">
                    <!-- CARD -->
                    <div class="text-center">
                        <div class="mx-auto">
                            <div class="mb-3">
                            <i class="fas fa-heart fa-3x"></i>
                            </div>
                            <span class="card-text">With supporting text below as a natural lead-in to additional content.</span>
                        </div>
                    </div>
                    <!-- CARD END-->
                </div>
                <!-- COL END -->
                <!-- COL -->
                <div class="col-sm">
                    <!-- CARD -->
                    <div class="text-center">
                        <div class="mx-auto">
                            <div class="mb-3">
                            <i class="fas fa-dove fa-3x"></i>
                            </div>
                            <span class="card-text">With supporting text below as a natural lead-in to additional content.</span>
                        </div>
                    </div>
                    <!-- CARD END-->
                </div>
                <!-- COL END -->
            </div>                    
        </div>
    </div>
</section>
<!-- END full-width section template -->

<!-- full-width section template -->
<section class="section w-100 p-5">
    <div class="container">
        <div class="row card-group">
            <!-- COL -->
            <div class="col-6">
                <!-- CARD -->
                <div class="card">
                    <img src="http://localhost:8080/sophromassage/wp-content/uploads/2019/07/generic.jpg" class="card-img" alt="...">
                    <div class="card-img-overlay">
                        <h5 class="card-title">Card title</h5>
                        <p class="card-text">This is a wider card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
                        <button type="button" class="btn btn-outline-dark">Button</button>
                        <button type="button" class="btn btn-outline-dark">Light</button>
                    </div>
                </div>
                <!-- END CARD -->
            </div>
            <!-- END COL -->
            <!-- COL -->
            <div class="col-6">
            <!-- CARD -->
            <div class="card">
                <img src="http://localhost:8080/sophromassage/wp-content/uploads/2019/07/generic.jpg" class="card-img" alt="...">
                <div class="card-img-overlay">
                    <h5 class="card-title">Card title</h5>
                    <p class="card-text">This is a wider card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
                    <button type="button" class="btn btn-outline-dark">Button</button>
                    <button type="button" class="btn btn-outline-dark">Light</button>
                </div>
            </div>
            <!-- END CARD -->
            <!-- END COL -->
        </div>
        <!-- END ROW -->
    </div>
    <!-- END CONTAINER -->
</section>
<!-- END SECTION -->

<!-- full-width section template -->
<section class="section w-100 p-5 bg-4 text-white">
<!-- CONTAINER -->
    <div class="container">
        <div class="row">
            <!-- COL -->
            <div class="col-6">
            <blockquote class="blockquote">
                <p class="mb-0">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer posuere erat a ante.</p>
            </blockquote>
            </div>
            <!-- END COL -->
            <!-- COL -->
            <div class="col-6">
            <form class="form-inline">
                <div class="form-group mx-sm-3 mb-2">
                    <input type="email" class="form-control" id="" placeholder="Ton adresse mail">
                </div>
                <button type="submit" class="btn btn-primary mb-2">Envoyer !</button>
            </form>
            </div>
            <!-- END COL -->
        </div>
    </div>
</section>
<!-- END SECTION -->

<!-- full-width section template -->
<section class="section w-100 p-5">
    <!-- CONTAINER -->
    <div class="container">
        <div class="card mb-3 border-0 rounded shadow">
            <div class="row no-gutters">
                <!-- col 8 -->
                <div class="col-md-8">
                    <div class="card-body">
                    <h3 class="font-weight-bold mb-4">Formulaire</h3>
                        <form>
                            <div class="row mb-4">
                                <div class="col input-group-lg">
                                    <input type="text" class="form-control" placeholder="Prénom">
                                </div>
                                <div class="col input-group-lg">
                                    <input type="text" class="form-control" placeholder="Nom">
                                </div>
                            </div>
                            <div class="row mb-4">
                                <div class="col input-group-lg">
                                    <input type="tel" class="form-control" placeholder="Téléphone">
                                </div>
                                <div class="col input-group-lg">
                                    <input type="email" class="form-control" placeholder="Adresse mail">
                                </div>
                            </div>
                            <div class="row mb-4">
                                <div class="col input-group-lg">
                                <select class="custom-select" id="inputGroupSelect01">
                                    <option selected>Status</option>
                                    <option value="1">Particulier</option>
                                    <option value="2">Professionnel</option>
                                </select>
                                </div>
                                <div class="col input-group-lg">
                                <select class="custom-select" id="inputGroupSelect01">
                                    <option selected>Object</option>
                                    <option value="1">Demande d'informations</option>
                                    <option value="2">Massage</option>
                                    <option value="3">Sophrologie</option>
                                    <option value="3">Offrir un cadeau</option>
                                    <option value="3">Autre</option>
                                </select>
                                </div>
                            </div>
                            <div class="input-group input-group-lg mb-4">
                                <textarea type="text" class="form-control" placeholder="Message"></textarea>
                            </div>
                            <div class="input-group mb-4 alert alert-secondary" role="alert">
                                <span class="">reCAPTCHA</span>
                            </div>
                            <button type="button" class="btn btn-primary btn-lg">Envoyer !</button>
                        </form>
                    </div>
                </div>
                <!-- col 4 -->
                <div class="col-md-4 bg-4 text-white p-4 rounded-right">
                    <h3 class="text-white font-weight-bold mb-4">Contact</h3>

                    <!-- <div class="card mb-3 text-dark">
                        <div class="row no-gutters">
                            <div class="col-md-4">
                            <i class="fas fa-hand-holding-heart mr-2 ico-l text-dark"></i>
                            </div>
                            <div class="col-md-8">
                            <div class="card-body">
                                <h5 class="card-title">Eléonore Hottou</h5>
                            </div>
                            </div>
                        </div>
                    </div> -->

                    <div class="mb-4">
                        <span class=""><i class="fas fa-hand-holding-heart mr-2 ico-s text-white"></i>Eléonore Hottou</span>
                    </div>
                    <div class="mb-4">
                        <span class=""><i class="fas fa-mobile-alt mr-2 ico-s text-white"></i>06 46 81 94 31</span>
                    </div>
                    <div class="mb-4">
                        <span class=""><i class="fas fa-paper-plane mr-2 ico-s text-white"></i>hello@sophromassage.fr</span>
                    </div>
                    <div class="mb-5">
                        <span class=""><i class="fas fa-map-signs mr-2 ico-s text-white"></i>Les Marjolaines bât. D,<br>296 av. louis Imbert,<br> 83160 La Valette-du-Var</span>
                    </div>
                    <!-- Button trigger modal -->
                    <div class="mb-5">
                        <button class="btn btn-link font-weight-bold p-0" type="button" data-toggle="modal" data-target="#heures-ouverture">Heures d'ouverture</button>
                    </div>
                    <!-- icons -->
                    <div class="mb-3">
                        <a href="" title="" alt=""><i class="fab fa-facebook-square mr-2 ico-s font-light-grey"></i></a>
                        <a href="" title="" alt=""><i class="fab fa-medium mr-2 ico-s font-light-grey"></i></a>
                    </div>
                    <!-- Modal -->
                    <div class="modal fade" id="heures-ouverture" tabindex="-1" role="dialog" aria-labelledby="heures-ouverture" aria-hidden="true">
                        <div class="modal-dialog" role="document">
                            <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="heures-ouverture">Heures d'ouverture</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div class="modal-body text-dark">
                            <p>
                                Lundi: 8h30 - 12h30 puis 13h30 - 20h00.
                                <br>
                                Mardi: 8h30 - 12h30 puis 13h30 - 20h00.
                                <br>
                                Mercredi: 8h30 - 12h30 puis 13h30 - 20h00.
                                <br>
                                Jeudi: 8h30 - 12h30 puis 13h30 - 20h00.
                                <br>
                                Vendredi: 8h30 - 12h30 puis 13h30 - 20h00.
                                <br>
                                Samedi: 10h00 - 20h00.
                                <br>
                                Dimanche: Fermé.
                            </p>
                            </div>
                            </div>
                        </div>
                    </div>
                    <!-- end Modal -->
                </div>
            </div>
        </div>
    </div>
</section>
<!-- END SECTION -->

<?php 
get_footer();
?>